# -*- coding: utf-8 -*-
"""
Default database settings
"""

DEFAULT_DB_URI = 'sqlite:///db/seishub.db'
DEFAULT_PREFIX = "default_"
DEFAULT_POOL_SIZE = 5
DEFAULT_MAX_OVERFLOW = 20
